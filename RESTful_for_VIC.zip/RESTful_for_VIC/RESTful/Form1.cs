﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace RESTful
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        HttpWebResponse response;
        Encoding encoding = Encoding.UTF8;
        Encoding encoding_asc = Encoding.ASCII;
        HttpWebRequest request;
        string full_url;
        string putdata;
        string comboSelectText;
        byte[] data;
        Stream datastream;
        StreamReader reader;

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        
        private void getBtn_Click(object sender, EventArgs e)
        {
            GET_response_text.Text = "";
            GET_response_status.Text = "Waiting...";
            full_url = "http://"+GET_IP_text.Text+"/restful";
            request = (HttpWebRequest)WebRequest.Create(full_url);
            request.Method = "GET";
            request.Timeout = 5000;
            request.ContentType = "application/x-www-form-urlencoded";      
            try
            {
                response = (HttpWebResponse)request.GetResponse();
                GET_response_status.Text = response.StatusCode.ToString();
                using (reader = new StreamReader(response.GetResponseStream(), encoding))
                {
                    GET_response_text.Text = reader.ReadToEnd();
                    reader.Close();
                }
            }
            catch
            {
                MessageBox.Show("Response Timeout");
                GET_response_status.Text = "Response Timeout";
            }
            //JObject json = JObject.Parse(result);
        }

        private void putBtn_Click(object sender, EventArgs e)
        {
            PUT_response_text.Text = "";
            PUT_response_status.Text = "Waiting...";
            comboSelectText = cmd_comboBox.Text;           
            putdata = "";
            full_url = "http://" + PUT_IP_text.Text + "/restful/put";
            request = (HttpWebRequest)WebRequest.Create(full_url);
            request.Timeout = 5000;
            switch (comboSelectText)
            {
                case "req_play":  //req_play
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_play&value=" + value_text.Text;
                    break;
                case "req_play_control":  //req_play_control
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_play_control&value=" + value_text.Text;
                    break;
                case "req_play_control_file":  //req_play_control_file
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_play_control_file&value=" + value_text.Text + "index_value=" + index_value_text.Text;
                    break;
                case "req_play_control_file_name":  //req_play_control_file_name
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_play_play_control_file_name&value=" + value_text.Text + "file_name=" + file_name_text.Text;
                    break;
                case "req_write_modbush_string":  //req_write_modbush_string
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_write_modbush_string&index_value=" + index_value_text.Text + "content=" + content_text.Text;
                    break;
                case "req_trigger_one_shot":  //req_trigger_one_shot
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_trigger_one_shot&value=" + value_text.Text;
                    break;
                case "req_trigger_page_assignment":  //req_trigger_page_assignment
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_trigger_page_assignment&index_value=" + index_value_text.Text;
                    break;
                case "req_trigger_database_write":  //req_trigger_database_write
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_trigger_database_write&value=" + value_text.Text;
                    break;
                case "req_trigger_use_recorder":  //req_trigger_use_recorder
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_trigger_use_recorder&value=" + value_text.Text;
                    break;
                case "req_trigger_record_event":  //req_trigger_record_event
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_trigger_record_event";
                    break;
                case "req_trigger_script_function":  //req_trigger_script_function
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_trigger_script_function&index_value=" + index_value_text.Text;
                    break;
                case "req_call_python_function":  //req_call_python_function
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_call_python_function&func="+func_text.Text;
                    if (self_defined_param_check_1.Checked == true)
                        putdata = putdata + "&" + self_defined_param_text_1.Text + "=" + self_defined_param_content_text_1.Text;
                    if (self_defined_param_check_2.Checked == true)
                        putdata = putdata + "&" + self_defined_param_text_2.Text + "=" + self_defined_param_content_text_2.Text;
                    if (self_defined_param_check_3.Checked == true)
                        putdata = putdata + "&" + self_defined_param_text_3.Text + "=" + self_defined_param_content_text_3.Text;
                    if (self_defined_param_check_4.Checked == true)
                        putdata = putdata + "&" + self_defined_param_text_4.Text + "=" + self_defined_param_content_text_4.Text;
                    if (self_defined_param_check_5.Checked == true)
                        putdata = putdata + "&" + self_defined_param_text_5.Text + "=" + self_defined_param_content_text_5.Text;
                    break;
                case "req_control_disable":  //req_control_disable
                    putdata = "username=" + username_text.Text + "&password=" + password_text.Text + "&cmd=req_control_disable&value=" + value_text.Text;
                    break;
                default:
                    putdata = "";
                    break;
            }

            request.Method = "PUT";
            request.ContentType = "application/x-www-form-urlencoded";
            data = encoding_asc.GetBytes(putdata);
            request.ContentLength = data.Length;
            
            try 
            {
                datastream = request.GetRequestStream();
                datastream.Write(data, 0, data.Length);
                datastream.Close();
                response = (HttpWebResponse)request.GetResponse();
                PUT_response_status.Text = response.StatusCode.ToString();
                using (reader = new StreamReader(response.GetResponseStream(), encoding))
                {
                    PUT_response_text.Text = reader.ReadToEnd();
                    reader.Close();
                }
            }
            catch
            {
                MessageBox.Show("Response Timeout");
                PUT_response_status.Text = "Response Timeout";
            }
            //JObject json = JObject.Parse(result);
        }


        private void cmd_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboSelectText = cmd_comboBox.Text;
            switch (comboSelectText)
            {
                case "req_play": //req_play
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_play_control":  //req_play_control
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_play_control_file":  //req_play_control_file
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = true;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_play_control_file_name":  //req_play_control_file_name
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = true;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_write_modbush_string":  //req_write_modbush_string
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = false;
                    index_value_text.Enabled = true;
                    file_name_text.Enabled = false;
                    content_text.Enabled = true;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_trigger_one_shot":  //req_trigger_one_shot
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_trigger_page_assignment":  //req_trigger_page_assignment
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = false;
                    index_value_text.Enabled = true;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_trigger_database_write":  //req_trigger_database_write
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_trigger_use_recorder":  //req_trigger_use_recorder
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_trigger_record_event":  //req_trigger_record_event
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = false;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_trigger_script_function":  //req_trigger_script_function
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = false;
                    index_value_text.Enabled = true;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                case "req_call_python_function":  //req_call_python_function
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = false;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = true;
                    self_defined_param_check_1.Enabled = true;
                    self_defined_param_check_2.Enabled = true;
                    self_defined_param_check_3.Enabled = true;
                    self_defined_param_check_4.Enabled = true;
                    self_defined_param_check_5.Enabled = true;
                    self_defined_param_text_1.Enabled = true;
                    self_defined_param_text_2.Enabled = true;
                    self_defined_param_text_3.Enabled = true;
                    self_defined_param_text_4.Enabled = true;
                    self_defined_param_text_5.Enabled = true;
                    self_defined_param_content_text_1.Enabled = true;
                    self_defined_param_content_text_2.Enabled = true;
                    self_defined_param_content_text_3.Enabled = true;
                    self_defined_param_content_text_4.Enabled = true;
                    self_defined_param_content_text_5.Enabled = true;
                    break;
                case "req_control_disable":  //req_control_disable
                    putBtn.Enabled = true;
                    username_text.Enabled = true;
                    password_text.Enabled = true;
                    value_text.Enabled = true;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_check_1.Enabled = false;
                    self_defined_param_check_2.Enabled = false;
                    self_defined_param_check_3.Enabled = false;
                    self_defined_param_check_4.Enabled = false;
                    self_defined_param_check_5.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
                default:
                    putBtn.Enabled = false;
                    username_text.Enabled = false;
                    password_text.Enabled = false;
                    value_text.Enabled = false;
                    index_value_text.Enabled = false;
                    file_name_text.Enabled = false;
                    content_text.Enabled = false;
                    func_text.Enabled = false;
                    self_defined_param_text_1.Enabled = false;
                    self_defined_param_text_2.Enabled = false;
                    self_defined_param_text_3.Enabled = false;
                    self_defined_param_text_4.Enabled = false;
                    self_defined_param_text_5.Enabled = false;
                    self_defined_param_content_text_1.Enabled = false;
                    self_defined_param_content_text_2.Enabled = false;
                    self_defined_param_content_text_3.Enabled = false;
                    self_defined_param_content_text_4.Enabled = false;
                    self_defined_param_content_text_5.Enabled = false;
                    break;
            }                
        }
    }
}
