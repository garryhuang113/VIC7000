﻿
namespace RESTful
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.putPage = new System.Windows.Forms.TabPage();
            this.PUT_IP_label = new System.Windows.Forms.Label();
            this.putBtn = new System.Windows.Forms.Button();
            this.PUT_IP_text = new System.Windows.Forms.TextBox();
            this.cmd_comboBox = new System.Windows.Forms.ComboBox();
            this.cmd_label = new System.Windows.Forms.Label();
            this.username_label = new System.Windows.Forms.Label();
            this.username_text = new System.Windows.Forms.TextBox();
            this.password_label = new System.Windows.Forms.Label();
            this.password_text = new System.Windows.Forms.TextBox();
            this.value_label = new System.Windows.Forms.Label();
            this.value_text = new System.Windows.Forms.TextBox();
            this.index_value_label = new System.Windows.Forms.Label();
            this.index_value_text = new System.Windows.Forms.TextBox();
            this.content_label = new System.Windows.Forms.Label();
            this.content_text = new System.Windows.Forms.TextBox();
            this.func_label = new System.Windows.Forms.Label();
            this.func_text = new System.Windows.Forms.TextBox();
            this.file_name_label = new System.Windows.Forms.Label();
            this.file_name_text = new System.Windows.Forms.TextBox();
            this.self_defined_param_label = new System.Windows.Forms.Label();
            this.self_defined_param_text_1 = new System.Windows.Forms.TextBox();
            this.self_defined_param_content_label = new System.Windows.Forms.Label();
            this.self_defined_param_content_text_1 = new System.Windows.Forms.TextBox();
            this.PUT_response_text = new System.Windows.Forms.RichTextBox();
            this.PUT_response_status = new System.Windows.Forms.Label();
            this.self_defined_param_text_2 = new System.Windows.Forms.TextBox();
            this.self_defined_param_content_text_2 = new System.Windows.Forms.TextBox();
            this.self_defined_param_text_3 = new System.Windows.Forms.TextBox();
            this.self_defined_param_content_text_3 = new System.Windows.Forms.TextBox();
            this.self_defined_param_text_4 = new System.Windows.Forms.TextBox();
            this.self_defined_param_content_text_4 = new System.Windows.Forms.TextBox();
            this.self_defined_param_text_5 = new System.Windows.Forms.TextBox();
            this.self_defined_param_content_text_5 = new System.Windows.Forms.TextBox();
            this.self_defined_param_check_1 = new System.Windows.Forms.CheckBox();
            this.self_defined_param_check_2 = new System.Windows.Forms.CheckBox();
            this.self_defined_param_check_3 = new System.Windows.Forms.CheckBox();
            this.self_defined_param_check_4 = new System.Windows.Forms.CheckBox();
            this.self_defined_param_check_5 = new System.Windows.Forms.CheckBox();
            this.getPage = new System.Windows.Forms.TabPage();
            this.getBtn = new System.Windows.Forms.Button();
            this.GET_IP_label = new System.Windows.Forms.Label();
            this.GET_IP_text = new System.Windows.Forms.TextBox();
            this.GET_response_text = new System.Windows.Forms.RichTextBox();
            this.GET_response_status = new System.Windows.Forms.Label();
            this.Mode = new System.Windows.Forms.TabControl();
            this.putPage.SuspendLayout();
            this.getPage.SuspendLayout();
            this.Mode.SuspendLayout();
            this.SuspendLayout();
            // 
            // putPage
            // 
            this.putPage.Controls.Add(this.self_defined_param_check_5);
            this.putPage.Controls.Add(this.self_defined_param_check_4);
            this.putPage.Controls.Add(this.self_defined_param_check_3);
            this.putPage.Controls.Add(this.self_defined_param_check_2);
            this.putPage.Controls.Add(this.self_defined_param_check_1);
            this.putPage.Controls.Add(this.self_defined_param_content_text_5);
            this.putPage.Controls.Add(this.self_defined_param_text_5);
            this.putPage.Controls.Add(this.self_defined_param_content_text_4);
            this.putPage.Controls.Add(this.self_defined_param_text_4);
            this.putPage.Controls.Add(this.self_defined_param_content_text_3);
            this.putPage.Controls.Add(this.self_defined_param_text_3);
            this.putPage.Controls.Add(this.self_defined_param_content_text_2);
            this.putPage.Controls.Add(this.self_defined_param_text_2);
            this.putPage.Controls.Add(this.PUT_response_text);
            this.putPage.Controls.Add(this.self_defined_param_content_text_1);
            this.putPage.Controls.Add(this.self_defined_param_text_1);
            this.putPage.Controls.Add(this.file_name_text);
            this.putPage.Controls.Add(this.func_text);
            this.putPage.Controls.Add(this.content_text);
            this.putPage.Controls.Add(this.index_value_text);
            this.putPage.Controls.Add(this.value_text);
            this.putPage.Controls.Add(this.password_text);
            this.putPage.Controls.Add(this.username_text);
            this.putPage.Controls.Add(this.PUT_IP_text);
            this.putPage.Controls.Add(this.PUT_response_status);
            this.putPage.Controls.Add(this.self_defined_param_content_label);
            this.putPage.Controls.Add(this.self_defined_param_label);
            this.putPage.Controls.Add(this.file_name_label);
            this.putPage.Controls.Add(this.func_label);
            this.putPage.Controls.Add(this.content_label);
            this.putPage.Controls.Add(this.index_value_label);
            this.putPage.Controls.Add(this.value_label);
            this.putPage.Controls.Add(this.password_label);
            this.putPage.Controls.Add(this.username_label);
            this.putPage.Controls.Add(this.cmd_label);
            this.putPage.Controls.Add(this.cmd_comboBox);
            this.putPage.Controls.Add(this.putBtn);
            this.putPage.Controls.Add(this.PUT_IP_label);
            this.putPage.Location = new System.Drawing.Point(4, 28);
            this.putPage.Name = "putPage";
            this.putPage.Padding = new System.Windows.Forms.Padding(3);
            this.putPage.Size = new System.Drawing.Size(972, 596);
            this.putPage.TabIndex = 1;
            this.putPage.Text = "PUT";
            this.putPage.UseVisualStyleBackColor = true;
            // 
            // PUT_IP_label
            // 
            this.PUT_IP_label.AutoSize = true;
            this.PUT_IP_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PUT_IP_label.Location = new System.Drawing.Point(28, 37);
            this.PUT_IP_label.Name = "PUT_IP_label";
            this.PUT_IP_label.Size = new System.Drawing.Size(74, 23);
            this.PUT_IP_label.TabIndex = 4;
            this.PUT_IP_label.Text = "VIC IP:";
            // 
            // putBtn
            // 
            this.putBtn.Enabled = false;
            this.putBtn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.putBtn.Location = new System.Drawing.Point(416, 24);
            this.putBtn.Name = "putBtn";
            this.putBtn.Size = new System.Drawing.Size(124, 48);
            this.putBtn.TabIndex = 3;
            this.putBtn.Text = "PUT";
            this.putBtn.UseVisualStyleBackColor = true;
            this.putBtn.Click += new System.EventHandler(this.putBtn_Click);
            // 
            // PUT_IP_text
            // 
            this.PUT_IP_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PUT_IP_text.Location = new System.Drawing.Point(106, 34);
            this.PUT_IP_text.Name = "PUT_IP_text";
            this.PUT_IP_text.Size = new System.Drawing.Size(258, 32);
            this.PUT_IP_text.TabIndex = 5;
            this.PUT_IP_text.Text = "10.12.1.34";
            // 
            // cmd_comboBox
            // 
            this.cmd_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmd_comboBox.FormattingEnabled = true;
            this.cmd_comboBox.Items.AddRange(new object[] {
            "req_play",
            "req_play_control",
            "req_play_control_file",
            "req_play_control_file_name",
            "req_write_modbush_string",
            "req_trigger_one_shot",
            "req_trigger_page_assignment",
            "req_trigger_database_write",
            "req_trigger_use_recorder",
            "req_trigger_record_event",
            "req_trigger_script_function",
            "req_call_python_function",
            "req_control_disable"});
            this.cmd_comboBox.Location = new System.Drawing.Point(85, 95);
            this.cmd_comboBox.Name = "cmd_comboBox";
            this.cmd_comboBox.Size = new System.Drawing.Size(206, 27);
            this.cmd_comboBox.TabIndex = 6;
            this.cmd_comboBox.SelectedIndexChanged += new System.EventHandler(this.cmd_comboBox_SelectedIndexChanged);
            // 
            // cmd_label
            // 
            this.cmd_label.AutoSize = true;
            this.cmd_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_label.Location = new System.Drawing.Point(28, 95);
            this.cmd_label.Name = "cmd_label";
            this.cmd_label.Size = new System.Drawing.Size(51, 23);
            this.cmd_label.TabIndex = 7;
            this.cmd_label.Text = "cmd:";
            // 
            // username_label
            // 
            this.username_label.AutoSize = true;
            this.username_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_label.Location = new System.Drawing.Point(28, 145);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(95, 23);
            this.username_label.TabIndex = 8;
            this.username_label.Text = "username:";
            // 
            // username_text
            // 
            this.username_text.Enabled = false;
            this.username_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_text.Location = new System.Drawing.Point(129, 142);
            this.username_text.Name = "username_text";
            this.username_text.Size = new System.Drawing.Size(235, 32);
            this.username_text.TabIndex = 9;
            this.username_text.Text = "admin";
            // 
            // password_label
            // 
            this.password_label.AutoSize = true;
            this.password_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_label.Location = new System.Drawing.Point(28, 183);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(94, 23);
            this.password_label.TabIndex = 10;
            this.password_label.Text = "password:";
            // 
            // password_text
            // 
            this.password_text.Enabled = false;
            this.password_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_text.Location = new System.Drawing.Point(128, 180);
            this.password_text.Name = "password_text";
            this.password_text.Size = new System.Drawing.Size(236, 32);
            this.password_text.TabIndex = 11;
            this.password_text.Text = "123456";
            // 
            // value_label
            // 
            this.value_label.AutoSize = true;
            this.value_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.value_label.Location = new System.Drawing.Point(28, 221);
            this.value_label.Name = "value_label";
            this.value_label.Size = new System.Drawing.Size(61, 23);
            this.value_label.TabIndex = 12;
            this.value_label.Text = "value:";
            // 
            // value_text
            // 
            this.value_text.Enabled = false;
            this.value_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.value_text.Location = new System.Drawing.Point(95, 218);
            this.value_text.Name = "value_text";
            this.value_text.Size = new System.Drawing.Size(269, 32);
            this.value_text.TabIndex = 13;
            this.value_text.Text = "1";
            // 
            // index_value_label
            // 
            this.index_value_label.AutoSize = true;
            this.index_value_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.index_value_label.Location = new System.Drawing.Point(28, 259);
            this.index_value_label.Name = "index_value_label";
            this.index_value_label.Size = new System.Drawing.Size(117, 23);
            this.index_value_label.TabIndex = 14;
            this.index_value_label.Text = "index_value:";
            // 
            // index_value_text
            // 
            this.index_value_text.Enabled = false;
            this.index_value_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.index_value_text.Location = new System.Drawing.Point(151, 256);
            this.index_value_text.Name = "index_value_text";
            this.index_value_text.Size = new System.Drawing.Size(213, 32);
            this.index_value_text.TabIndex = 15;
            this.index_value_text.Text = "0";
            // 
            // content_label
            // 
            this.content_label.AutoSize = true;
            this.content_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.content_label.Location = new System.Drawing.Point(28, 335);
            this.content_label.Name = "content_label";
            this.content_label.Size = new System.Drawing.Size(77, 23);
            this.content_label.TabIndex = 16;
            this.content_label.Text = "content:";
            // 
            // content_text
            // 
            this.content_text.Enabled = false;
            this.content_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.content_text.Location = new System.Drawing.Point(111, 332);
            this.content_text.Name = "content_text";
            this.content_text.Size = new System.Drawing.Size(253, 32);
            this.content_text.TabIndex = 17;
            // 
            // func_label
            // 
            this.func_label.AutoSize = true;
            this.func_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.func_label.Location = new System.Drawing.Point(28, 373);
            this.func_label.Name = "func_label";
            this.func_label.Size = new System.Drawing.Size(53, 23);
            this.func_label.TabIndex = 18;
            this.func_label.Text = "func:";
            // 
            // func_text
            // 
            this.func_text.Enabled = false;
            this.func_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.func_text.Location = new System.Drawing.Point(87, 370);
            this.func_text.Name = "func_text";
            this.func_text.Size = new System.Drawing.Size(277, 32);
            this.func_text.TabIndex = 19;
            // 
            // file_name_label
            // 
            this.file_name_label.AutoSize = true;
            this.file_name_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.file_name_label.Location = new System.Drawing.Point(28, 297);
            this.file_name_label.Name = "file_name_label";
            this.file_name_label.Size = new System.Drawing.Size(99, 23);
            this.file_name_label.TabIndex = 20;
            this.file_name_label.Text = "file_name:";
            // 
            // file_name_text
            // 
            this.file_name_text.Enabled = false;
            this.file_name_text.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.file_name_text.Location = new System.Drawing.Point(128, 294);
            this.file_name_text.Name = "file_name_text";
            this.file_name_text.Size = new System.Drawing.Size(236, 32);
            this.file_name_text.TabIndex = 21;
            // 
            // self_defined_param_label
            // 
            this.self_defined_param_label.AutoSize = true;
            this.self_defined_param_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_label.Location = new System.Drawing.Point(496, 116);
            this.self_defined_param_label.Name = "self_defined_param_label";
            this.self_defined_param_label.Size = new System.Drawing.Size(174, 23);
            this.self_defined_param_label.TabIndex = 22;
            this.self_defined_param_label.Text = "self_defined_param";
            // 
            // self_defined_param_text_1
            // 
            this.self_defined_param_text_1.Enabled = false;
            this.self_defined_param_text_1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_text_1.Location = new System.Drawing.Point(509, 152);
            this.self_defined_param_text_1.Name = "self_defined_param_text_1";
            this.self_defined_param_text_1.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_text_1.TabIndex = 23;
            // 
            // self_defined_param_content_label
            // 
            this.self_defined_param_content_label.AutoSize = true;
            this.self_defined_param_content_label.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_content_label.Location = new System.Drawing.Point(720, 116);
            this.self_defined_param_content_label.Name = "self_defined_param_content_label";
            this.self_defined_param_content_label.Size = new System.Drawing.Size(246, 23);
            this.self_defined_param_content_label.TabIndex = 24;
            this.self_defined_param_content_label.Text = "self_defined_param_content";
            // 
            // self_defined_param_content_text_1
            // 
            this.self_defined_param_content_text_1.Enabled = false;
            this.self_defined_param_content_text_1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_content_text_1.Location = new System.Drawing.Point(782, 152);
            this.self_defined_param_content_text_1.Name = "self_defined_param_content_text_1";
            this.self_defined_param_content_text_1.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_content_text_1.TabIndex = 25;
            // 
            // PUT_response_text
            // 
            this.PUT_response_text.Location = new System.Drawing.Point(3, 408);
            this.PUT_response_text.Name = "PUT_response_text";
            this.PUT_response_text.Size = new System.Drawing.Size(968, 187);
            this.PUT_response_text.TabIndex = 26;
            this.PUT_response_text.Text = "";
            // 
            // PUT_response_status
            // 
            this.PUT_response_status.AutoSize = true;
            this.PUT_response_status.Location = new System.Drawing.Point(605, 37);
            this.PUT_response_status.Name = "PUT_response_status";
            this.PUT_response_status.Size = new System.Drawing.Size(0, 19);
            this.PUT_response_status.TabIndex = 27;
            // 
            // self_defined_param_text_2
            // 
            this.self_defined_param_text_2.Enabled = false;
            this.self_defined_param_text_2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_text_2.Location = new System.Drawing.Point(509, 199);
            this.self_defined_param_text_2.Name = "self_defined_param_text_2";
            this.self_defined_param_text_2.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_text_2.TabIndex = 28;
            // 
            // self_defined_param_content_text_2
            // 
            this.self_defined_param_content_text_2.Enabled = false;
            this.self_defined_param_content_text_2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_content_text_2.Location = new System.Drawing.Point(782, 199);
            this.self_defined_param_content_text_2.Name = "self_defined_param_content_text_2";
            this.self_defined_param_content_text_2.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_content_text_2.TabIndex = 29;
            // 
            // self_defined_param_text_3
            // 
            this.self_defined_param_text_3.Enabled = false;
            this.self_defined_param_text_3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_text_3.Location = new System.Drawing.Point(509, 250);
            this.self_defined_param_text_3.Name = "self_defined_param_text_3";
            this.self_defined_param_text_3.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_text_3.TabIndex = 30;
            // 
            // self_defined_param_content_text_3
            // 
            this.self_defined_param_content_text_3.Enabled = false;
            this.self_defined_param_content_text_3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_content_text_3.Location = new System.Drawing.Point(782, 250);
            this.self_defined_param_content_text_3.Name = "self_defined_param_content_text_3";
            this.self_defined_param_content_text_3.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_content_text_3.TabIndex = 31;
            // 
            // self_defined_param_text_4
            // 
            this.self_defined_param_text_4.Enabled = false;
            this.self_defined_param_text_4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_text_4.Location = new System.Drawing.Point(509, 297);
            this.self_defined_param_text_4.Name = "self_defined_param_text_4";
            this.self_defined_param_text_4.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_text_4.TabIndex = 32;
            // 
            // self_defined_param_content_text_4
            // 
            this.self_defined_param_content_text_4.Enabled = false;
            this.self_defined_param_content_text_4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_content_text_4.Location = new System.Drawing.Point(782, 297);
            this.self_defined_param_content_text_4.Name = "self_defined_param_content_text_4";
            this.self_defined_param_content_text_4.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_content_text_4.TabIndex = 33;
            // 
            // self_defined_param_text_5
            // 
            this.self_defined_param_text_5.Enabled = false;
            this.self_defined_param_text_5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_text_5.Location = new System.Drawing.Point(509, 347);
            this.self_defined_param_text_5.Name = "self_defined_param_text_5";
            this.self_defined_param_text_5.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_text_5.TabIndex = 34;
            // 
            // self_defined_param_content_text_5
            // 
            this.self_defined_param_content_text_5.Enabled = false;
            this.self_defined_param_content_text_5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self_defined_param_content_text_5.Location = new System.Drawing.Point(782, 347);
            this.self_defined_param_content_text_5.Name = "self_defined_param_content_text_5";
            this.self_defined_param_content_text_5.Size = new System.Drawing.Size(145, 32);
            this.self_defined_param_content_text_5.TabIndex = 35;
            // 
            // self_defined_param_check_1
            // 
            this.self_defined_param_check_1.AutoSize = true;
            this.self_defined_param_check_1.Location = new System.Drawing.Point(488, 161);
            this.self_defined_param_check_1.Name = "self_defined_param_check_1";
            this.self_defined_param_check_1.Size = new System.Drawing.Size(15, 14);
            this.self_defined_param_check_1.TabIndex = 36;
            this.self_defined_param_check_1.UseVisualStyleBackColor = true;
            // 
            // self_defined_param_check_2
            // 
            this.self_defined_param_check_2.AutoSize = true;
            this.self_defined_param_check_2.Location = new System.Drawing.Point(488, 208);
            this.self_defined_param_check_2.Name = "self_defined_param_check_2";
            this.self_defined_param_check_2.Size = new System.Drawing.Size(15, 14);
            this.self_defined_param_check_2.TabIndex = 37;
            this.self_defined_param_check_2.UseVisualStyleBackColor = true;
            // 
            // self_defined_param_check_3
            // 
            this.self_defined_param_check_3.AutoSize = true;
            this.self_defined_param_check_3.Location = new System.Drawing.Point(488, 259);
            this.self_defined_param_check_3.Name = "self_defined_param_check_3";
            this.self_defined_param_check_3.Size = new System.Drawing.Size(15, 14);
            this.self_defined_param_check_3.TabIndex = 38;
            this.self_defined_param_check_3.UseVisualStyleBackColor = true;
            // 
            // self_defined_param_check_4
            // 
            this.self_defined_param_check_4.AutoSize = true;
            this.self_defined_param_check_4.Location = new System.Drawing.Point(488, 306);
            this.self_defined_param_check_4.Name = "self_defined_param_check_4";
            this.self_defined_param_check_4.Size = new System.Drawing.Size(15, 14);
            this.self_defined_param_check_4.TabIndex = 39;
            this.self_defined_param_check_4.UseVisualStyleBackColor = true;
            // 
            // self_defined_param_check_5
            // 
            this.self_defined_param_check_5.AutoSize = true;
            this.self_defined_param_check_5.Location = new System.Drawing.Point(488, 356);
            this.self_defined_param_check_5.Name = "self_defined_param_check_5";
            this.self_defined_param_check_5.Size = new System.Drawing.Size(15, 14);
            this.self_defined_param_check_5.TabIndex = 40;
            this.self_defined_param_check_5.UseVisualStyleBackColor = true;
            // 
            // getPage
            // 
            this.getPage.Controls.Add(this.GET_response_status);
            this.getPage.Controls.Add(this.GET_response_text);
            this.getPage.Controls.Add(this.GET_IP_text);
            this.getPage.Controls.Add(this.GET_IP_label);
            this.getPage.Controls.Add(this.getBtn);
            this.getPage.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getPage.Location = new System.Drawing.Point(4, 28);
            this.getPage.Name = "getPage";
            this.getPage.Padding = new System.Windows.Forms.Padding(3);
            this.getPage.Size = new System.Drawing.Size(972, 596);
            this.getPage.TabIndex = 0;
            this.getPage.Text = "GET";
            this.getPage.UseVisualStyleBackColor = true;
            // 
            // getBtn
            // 
            this.getBtn.Location = new System.Drawing.Point(440, 15);
            this.getBtn.Name = "getBtn";
            this.getBtn.Size = new System.Drawing.Size(124, 48);
            this.getBtn.TabIndex = 0;
            this.getBtn.Text = "GET";
            this.getBtn.UseVisualStyleBackColor = true;
            this.getBtn.Click += new System.EventHandler(this.getBtn_Click);
            // 
            // GET_IP_label
            // 
            this.GET_IP_label.AutoSize = true;
            this.GET_IP_label.Location = new System.Drawing.Point(57, 28);
            this.GET_IP_label.Name = "GET_IP_label";
            this.GET_IP_label.Size = new System.Drawing.Size(74, 23);
            this.GET_IP_label.TabIndex = 1;
            this.GET_IP_label.Text = "VIC IP:";
            // 
            // GET_IP_text
            // 
            this.GET_IP_text.Location = new System.Drawing.Point(135, 24);
            this.GET_IP_text.Name = "GET_IP_text";
            this.GET_IP_text.Size = new System.Drawing.Size(258, 32);
            this.GET_IP_text.TabIndex = 2;
            this.GET_IP_text.Text = "10.12.1.34";
            // 
            // GET_response_text
            // 
            this.GET_response_text.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GET_response_text.Location = new System.Drawing.Point(5, 80);
            this.GET_response_text.Name = "GET_response_text";
            this.GET_response_text.Size = new System.Drawing.Size(964, 515);
            this.GET_response_text.TabIndex = 3;
            this.GET_response_text.Text = "";
            // 
            // GET_response_status
            // 
            this.GET_response_status.AutoSize = true;
            this.GET_response_status.Location = new System.Drawing.Point(649, 28);
            this.GET_response_status.Name = "GET_response_status";
            this.GET_response_status.Size = new System.Drawing.Size(0, 23);
            this.GET_response_status.TabIndex = 4;
            // 
            // Mode
            // 
            this.Mode.Controls.Add(this.getPage);
            this.Mode.Controls.Add(this.putPage);
            this.Mode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mode.Location = new System.Drawing.Point(-1, 0);
            this.Mode.Name = "Mode";
            this.Mode.SelectedIndex = 0;
            this.Mode.Size = new System.Drawing.Size(980, 628);
            this.Mode.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 627);
            this.Controls.Add(this.Mode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "RESTful Client Sample for VIC";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.putPage.ResumeLayout(false);
            this.putPage.PerformLayout();
            this.getPage.ResumeLayout(false);
            this.getPage.PerformLayout();
            this.Mode.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage putPage;
        private System.Windows.Forms.CheckBox self_defined_param_check_5;
        private System.Windows.Forms.CheckBox self_defined_param_check_4;
        private System.Windows.Forms.CheckBox self_defined_param_check_3;
        private System.Windows.Forms.CheckBox self_defined_param_check_2;
        private System.Windows.Forms.CheckBox self_defined_param_check_1;
        private System.Windows.Forms.TextBox self_defined_param_content_text_5;
        private System.Windows.Forms.TextBox self_defined_param_text_5;
        private System.Windows.Forms.TextBox self_defined_param_content_text_4;
        private System.Windows.Forms.TextBox self_defined_param_text_4;
        private System.Windows.Forms.TextBox self_defined_param_content_text_3;
        private System.Windows.Forms.TextBox self_defined_param_text_3;
        private System.Windows.Forms.TextBox self_defined_param_content_text_2;
        private System.Windows.Forms.TextBox self_defined_param_text_2;
        private System.Windows.Forms.RichTextBox PUT_response_text;
        private System.Windows.Forms.TextBox self_defined_param_content_text_1;
        private System.Windows.Forms.TextBox self_defined_param_text_1;
        private System.Windows.Forms.TextBox file_name_text;
        private System.Windows.Forms.TextBox func_text;
        private System.Windows.Forms.TextBox content_text;
        private System.Windows.Forms.TextBox index_value_text;
        private System.Windows.Forms.TextBox value_text;
        private System.Windows.Forms.TextBox password_text;
        private System.Windows.Forms.TextBox username_text;
        private System.Windows.Forms.TextBox PUT_IP_text;
        private System.Windows.Forms.Label PUT_response_status;
        private System.Windows.Forms.Label self_defined_param_content_label;
        private System.Windows.Forms.Label self_defined_param_label;
        private System.Windows.Forms.Label file_name_label;
        private System.Windows.Forms.Label func_label;
        private System.Windows.Forms.Label content_label;
        private System.Windows.Forms.Label index_value_label;
        private System.Windows.Forms.Label value_label;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.Label cmd_label;
        private System.Windows.Forms.ComboBox cmd_comboBox;
        private System.Windows.Forms.Button putBtn;
        private System.Windows.Forms.Label PUT_IP_label;
        private System.Windows.Forms.TabPage getPage;
        private System.Windows.Forms.Label GET_response_status;
        private System.Windows.Forms.RichTextBox GET_response_text;
        private System.Windows.Forms.TextBox GET_IP_text;
        private System.Windows.Forms.Label GET_IP_label;
        private System.Windows.Forms.Button getBtn;
        private System.Windows.Forms.TabControl Mode;
    }
}

